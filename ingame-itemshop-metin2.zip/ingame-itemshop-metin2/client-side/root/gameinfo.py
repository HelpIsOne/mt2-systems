PYTHONISLEM = 0
PYTHONTOLUA = ""

INPUT = 0

CLIENT_YOL = "lib/"
CONFIG_YOL = "locale/tr/ui/"

ITEMSHOP_SITE = "http://www.sportmt2.com"
ITEMSHOP_ACIK = 0
ITEMSHOP_OPEN = 0
ITEMSHOP_TIME = 0
ITEMSHOP_SATINALMA_SURESI = 10
ITEMSHOP_SATINALDIKLARIM = {}
ITEMSHOP_BEDAVAITEMLER = {
	"bedavamenu1" : {}, "bedavamenu2" : {}, "bedavamenu3" : {}, "bedavamenu4" : {}, "bedavamenu5" : {}, 
	"bedavamenu6" : {}, "bedavamenu7" : {}, "bedavamenu8" : {}, "bedavamenu9" : {}, "bedavamenu10" : {}, 
	"bedavamenu11" : {}, "bedavamenu12" : {},
	
	"bedavamenu1_isim": "Bedava Silahlar",
	"bedavamenu2_isim": "Bedava Silahlar2",
	"bedavamenu3_isim": "Bedava Silahlar3",
	"bedavamenu4_isim": "Bedava Silahlar4",
	"bedavamenu5_isim": "Bedava Silahlar5",
	"bedavamenu6_isim": "Bedava Silahlar6",
	"bedavamenu7_isim": "Bedava Silahlar7",
	"bedavamenu8_isim": "Bedava Silahlar8",
	"bedavamenu9_isim": "Bedava Silahlar9",
	"bedavamenu10_isim": "Bedava Silahlar10",
	"bedavamenu11_isim": "Bedava Silahlar11",
	"bedavamenu12_isim": "Bedava Silahlar12",
	
}

ITEMSHOP_NORMALITEMLER = {
	"normalmenu1" : {}, "normalmenu2" : {}, "normalmenu3" : {}, "normalmenu4" : {}, "normalmenu5" : {}, 
	"normalmenu6" : {}, "normalmenu7" : {}, "normalmenu8" : {}, "normalmenu9" : {}, "normalmenu10" : {}, 
	"normalmenu11" : {}, "normalmenu12" : {},
	
	"normalmenu1_isim": "Normal Silahlar",
	"normalmenu2_isim": "Normal Silahlar2",
	"normalmenu3_isim": "Normal Silahlar3",
	"normalmenu4_isim": "Normal Silahlar4",
	"normalmenu5_isim": "Normal Silahlar5",
	"normalmenu6_isim": "Normal Silahlar6",
	"normalmenu7_isim": "Normal Silahlar7",
	"normalmenu8_isim": "Normal Silahlar8",
	"normalmenu9_isim": "Normal Silahlar9",
	"normalmenu10_isim": "Normal Silahlar10",
	"normalmenu11_isim": "Normal Silahlar11",
	"normalmenu12_isim": "Normal Silahlar12",
	
}
ITEMSHOP_EP = 0
ITEMSHOP_SILAHLAR = {}
ITEMSHOP_ZIRHLAR = {}
ITEMSHOP_TAKILAR = {}
ITEMSHOP_BASMA = {}
ITEMSHOP_KALKAN_KASK = {}
ITEMSHOP_DIGER = {}