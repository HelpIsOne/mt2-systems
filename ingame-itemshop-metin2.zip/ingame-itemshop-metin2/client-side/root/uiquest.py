import gameInfo

## A��a��daki Class'�n, def__init__ fonksiyonun i�ine ekle!!! ##
class QuestDialog(ui.ScriptWindow):
	def __init__(self,skin,idx):
		if gameInfo.INPUT == 1:
			return