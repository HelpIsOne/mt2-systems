				#inside it 
				{
					"name" : "Character_Page",
					"type" : "window",
					"style" : ("attach",),

					"x" : 0,
					"y" : 0,

					"width" : 250,
					"height" : 304,

					"children" :
					(

						# add 
						{
							"name" : "durum",
							"type" : "image",
							
							"x": 153 + 95 - 15-25-15+10+4,
							"y": 25+6+2+1,
							
							"image" : "",
						},
						
						{
							"name" : "sec",
							"type" : "button",
							
							"x" : 153 + 95 + 15 - 15-15-15+5+4,
							"y" : 25+6+2+1,
							
							"default_image" : "locale/ui/+.tga",
							"over_image" : "locale/ui/+.tga",
							"down_image" : "locale/ui/+.tga",
						},
		