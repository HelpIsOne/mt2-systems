import ui

SYSTEM_PATH = "http://www.riot2.com/systems/"
SYSTEM_LOGIN_DUYURULAR_PATH = "http://www.xxx.com/systems/duyurular.cfg"
SYSTEM_HESAP_PATH = "http://www.riot2.com/systems/hesapsystem.php"

RIOT_PRIVATESHOP_NAME = ""
RIOT_PRIVATESHOP = []
TEMA = open("lib/config_tema.cfg", "r").read()

tool = 0
Ep = ""
N = 0
BuNP = 0
NSayfa = 0
ItemShopSuanAcik = 0
KILLEFEKTSTAT = 1
killmeee = 0
ItemStatus = ""
ItemShopSatinAl = 0
Aranan = 0
ArananItemKod = ""
ArananItemLevel = ""
ItemShopItemleri = 0
Itemler = [149]
SavasStat = 0
SavasRakip = ""
KarsiVID = ""
Gelenmesajadeti = 0
GonderenKisiler = []
opentarget = 0
koyulansuan = 0
suanvid = 0
SonGonderen = ""
AcilisZaman = 0
Geldila = 0
Line = ""
ziyaretcitemshop = 0
ScrollKapat = 0
konusmadurumu = []
Kiminle = ""
Ben = ""
DUELLODAIZINVARMI = ""
BenimDuelloIznim = ""
Puan = ""
yaziyor = 0
kankapatfix = 0
Ticlevel = 0

yazanlar = []

GirSifre = ""
Stat = ""
OlSifre = ""
listeyiyenile = 0

Nere = ""
isinlanma = 0
lenname = ""

#Configs
ConfigIslem = ""
ConfigToLua = 0
LuaToConfig = 0

#Hesap
ConfigToLuaH = 0
ConfigIslemH = ""
ConfigYeni = ""
ConfigEski = ""
ConfigBilgiler = ""
Eposta = ""

kadi = ""
pw = ""
configeposta = ""
kkod = ""

#Renklendirmeler
Renkler = {
	'suan' : "beyaz",
	'siyah' : "|cFF000000|H|h",
	'beyaz' : "|c000000|H|h", 
	'yesil' : "|cFF32CD32|H|h",
	'mavi'  : "|cFF0080FF|H|h",
	'pembe' : "|cFFFF00FF|H|h",
	'kirmizi' : "|cFFFF0000|H|h",
	'sari' : "|cFFFFFF00|H|h"
	
}

Renkler2 = {
	'siyah' : "|c1f1919|H|h",
	'beyaz' : "|cFFFFFF|H|h",
	'yesil' : "|c1c1f19|H|h",
	'mavi'  : "|cFF0080FF|H|h",
	'pembe' : "|cFFFF00FF|H|h",
	'kirmizi' : "|cFFFF0000|H|h",
	'sari' : "|cFFFFFF00|H|h"
	
}

#Siralama
OyuncuAra = 0
OyuncuBilgileri = ["", "", "", ""]
OyuncuAdi = ""
OYUNCULAR = {
	"oyuncular" : {},
}

Mesajlar = {}

#Python To Quest i�lemleri:
QuestSetting = ""
QuestSetting2 = ""
QuestSetting3 = ""
Son3 = ""
QuestSettingNe = ""
MesajKime = ""
QuestCMD = 0
Messageler = ""
GelenMesaj = ""
Acildi = 0
YerNO = 0
BenYolladim = 0

Konusmalarim = {
	"KONUSMALAR" : {},
}