#Prof Whisper System, V.2.6
#by Fatihbab34�

aciklar = []
yolla = 0
killmeee = 0
bildirimler = 0

mds = 0
mod = "on"
rakipmod = ""
modduzenle = 0
mesajat = 0
loncaacik = 0
listkapat = 0
sendile = 0
envantersafebox = 0
solust_yer = 0
ticsinif = 0
ticlonca = ""

GidenMesaj = ""

Secilen = ""
BarDurum = 0

Dbregg = 0
KralPy = 0
Olustur2 = 0

DondurCark = 0
KaderAc = 0

group_add = "" 
group_new_name = "" 
group_chat_enable = 0 
group_chat = "" 
groups = {}
groupslider = {}
groupssessiz = {}
konusmasessiz = {}

degisenler = []
yenigirilen = ""
GrupMesajiBu = 0
suan = 0
newad = ""

yenipencere = 0
yeniad = ""
yapimcilar = 0
env=0
adam=""
envanter = 0

Oto = 0
OtoMesaj = ""

rakipimza = ""

OtoToplama = 1
OtoYang = 0

listeyenilelan = 0

hediyevar = 0


Np = 0

KarsiLevel = 0
KarsiGor = ""

SorunBildir = 0
SorunGirilen = ""

YardimAl = 0

GIFTSYS = 1

AFK = 0
INPUT_IGNORE = 0
Adi = ""