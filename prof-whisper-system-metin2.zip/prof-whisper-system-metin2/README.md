# prof-whisper-system-metin2
 Metin2 Prof Whisper System

Warning: This project was developed in 2014 and is no longer supported. 
Unnecessary files that are not related to the system can also be found in the shared files. 
Therefore, those who want to use this system should clean them. 
And it might have a lot of bugs. Feel free to use, find bugs and fix it :)

Video link: https://www.youtube.com/watch?v=zFxeCLdMXUs
