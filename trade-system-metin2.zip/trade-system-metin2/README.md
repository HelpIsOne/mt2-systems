# trade-system-metin2
 Metin2 Trade System

Warning: This project was developed in 2015 and is no longer supported. It might have a lot of bugs. Feel free to use, find bugs and fix it :)

Video: https://www.youtube.com/watch?v=686LTFMGLMQ
