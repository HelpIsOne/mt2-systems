ALISVERIS = {
	"itemler" : {},
	"myitems" : {},
	"pythontolua" : 0,
	"islem" : "",
}