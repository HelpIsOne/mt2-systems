# recyclebin-for-items
 
Warning: This project was developed in 2016 and is no longer supported. It might have a lot of bugs. Feel free to use, find bugs and fix it :)

Video: https://www.youtube.com/watch?v=Ve6qJ0sy3JE
