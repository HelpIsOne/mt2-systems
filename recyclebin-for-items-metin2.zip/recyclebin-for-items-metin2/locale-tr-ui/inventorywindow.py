import gameInfo

		# in Equipment_Base
		{"name":"topluSILbutton","type":"button","x":119,"y":147-38,"default_image":str(gameInfo.CONFIG_YOL)+"toplusil.tga","over_image":str(gameInfo.CONFIG_YOL)+"toplusil2.tga","down_image":str(gameInfo.CONFIG_YOL)+"toplusil2.tga"},