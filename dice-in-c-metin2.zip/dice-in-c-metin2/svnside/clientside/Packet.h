// [SEARCH THIS]
typedef struct command_exchange
	// [FIND THIS]
		BYTE		arg2;
	// [ADD UNDER]
		BYTE		dice;

// [SEARCH THIS]
typedef struct packet_exchange
	// [FIND THIS]
		DWORD       arg3;
	// [ADD UNDER]
		BYTE		dice;