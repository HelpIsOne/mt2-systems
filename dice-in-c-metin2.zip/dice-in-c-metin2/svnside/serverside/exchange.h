	// [SEARCH]
		CExchange(LPCHARACTER pOwner);
	// [REPLACE]
		CExchange(LPCHARACTER pOwner, BYTE dice);
		
	// [SEARCH]
		long		m_lGold;
	// [ADD UNDER]
		BYTE		m_lDice;