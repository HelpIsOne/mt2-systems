	// [SEARCH]
		ch->ExchangeStart(to_ch);
	// [REPLACE WITH THAT]
		ch->ExchangeStart(to_ch, pinfo->dice);