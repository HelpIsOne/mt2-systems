// [SEARCH]
ACMD(do_xmas);
// [ADD UNDER, NOTE: if there is already that one, you don't need to add this again.]
ACMD(do_dice_new);

// [SEARCH]
{ "xmas_santa",	do_xmas,		SCMD_XMAS_SANTA,	POS_DEAD,	GM_HIGH_WIZARD	},
// [ADD UNDER]
{ "dice_system",	do_dice_new,		0,	POS_DEAD,	GM_HIGH_WIZARD	},