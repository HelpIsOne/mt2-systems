	// [SEARCH]
	bool			ExchangeStart(LPCHARACTER victim);
	// [REPLACE]
	bool			ExchangeStart(LPCHARACTER victim, BYTE dice);