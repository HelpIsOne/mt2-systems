// [SEARCH THIS]
typedef struct command_exchange
	// [FIND]
		BYTE	arg2;
	// [ADD UNDER]
		BYTE	dice;
		
// [SEARCH THIS]
struct packet_exchange
	// [FIND]
		DWORD	arg3;	// count
	// [ADD UNDER]
		BYTE	dice;