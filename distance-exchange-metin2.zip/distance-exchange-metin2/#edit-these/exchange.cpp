	//search and delete
	
	if (iDist >= EXCHANGE_MAX_DISTANCE)
		return false;