				{
					"name" : "uzaktanticaretbutton",
					"type" : "button",

					"x" : 145 + 65,
					"y" : 10,

					"text" : "U-T",
					"tooltip_text" : "Uzaktan Ticaret teklifi gönder!",

					"default_image" : "d:/ymir work/ui/public/xsmall_button_01.sub",
					"over_image" : "d:/ymir work/ui/public/xsmall_button_02.sub",
					"down_image" : "d:/ymir work/ui/public/xsmall_button_03.sub",
				},