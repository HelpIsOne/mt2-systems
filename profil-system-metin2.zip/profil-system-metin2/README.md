# profil-system-metin2
 
Video: https://www.youtube.com/watch?v=36e-TYUsGE0
