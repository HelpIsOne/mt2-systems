import gameInfo

class QuestDialog(ui.ScriptWindow):

	def __init__(self,skin,idx):
		if gameInfo.INPUT == 1:
			return
