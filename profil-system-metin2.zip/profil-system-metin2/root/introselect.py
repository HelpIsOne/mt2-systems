import gameInfo

	def Open(self):
		gameInfo.PROFIL_DURUM = 0