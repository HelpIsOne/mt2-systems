PYTHONTOLUA = 0
PYTHONISLEM = ""

CONFIG_YOL="locale/tr/ui/config"

INPUT = 0

PROFIL = {

	"DURUM" : 1,#0:onaylanmış, 1:onaylanmamış
	"PAYLASIM" : 0,#1:herkez görsün, 2:sadece arkadaşlar, 3:gizlilik
	"CINSIYET" : ".",
	"YAS" : ".",
	"IS" : ".",
	"ISYER" : ".",
	"SEHIR" : ".",
	"ILCE" : ".",
	"DOGUM-GUNU" : ".",
	"DOGUM-GUNU2" : ".",
	"BURC" : ".",
	"FACEBOOK" : ".", 
	"WEBSITE" : ".", 
	"E-POSTA" : ".", 
	"SKYPE" : ".", 
	"KISISEL" : "."
}
PROFIL_DURUM = 0 #0:onaylanmış, 1:onaylanmamış
PROFIL_BUTTON = 1
PROFIL_NAME = ""
PROFIL_LIST = []
PROFIL_EKRANI = 0
PROFIL_AC = 0
PROFIL_ISHOW = 0
PROFIL_TARGET = 0
TARGET=0