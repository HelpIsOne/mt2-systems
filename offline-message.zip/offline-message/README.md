# offline-message-metin2
 
Video: https://www.youtube.com/watch?v=Tb5sySjCah0
