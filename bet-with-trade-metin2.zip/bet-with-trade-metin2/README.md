# bet-with-trade-metin2
 
Warning: This system was developed in 2015 and is no longer supported. It might have a lot of bugs. Feel free to use, find bugs and fix it :)
