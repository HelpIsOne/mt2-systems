SYSTEM_PATH = "/usr/game/share/locale/turkey/quest/systems/"

BAHIS_RANDOM = {1,100}
BAHIS_SISTEMI = 0