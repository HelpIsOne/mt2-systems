import gameInfo

	def OnUpdate(self):
		if len(gameInfo.DICE_SYSTEM) > 0:
			self.Close()